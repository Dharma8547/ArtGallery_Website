<?php
error_reporting(0);
session_start();

if(!isset($_SESSION["user"])){
  header("Location: login.php");
}

if(isset($_POST["prd_id"])){

$id=$_POST["prd_id"];
$username=$_SESSION['user'];



$conn=mysqli_connect('localhost','root','','art_gallery');

 if(!$conn) {
      die('Could not connect');
   }

   
   $sql = "INSERT INTO bag
      VALUES ('$id','$username',1)";



   $retval = mysqli_query( $conn, $sql );
   
   if(!$retval) {
      die('Could not enter data');
   }
   
   //$row = mysqli_fetch_assoc($result);

   // Display the selected product information
   //echo "Selected product: " . $row['product_name'];
   
   header("Location: bag2.php");
}else{
      header("Location: p2.php");
die();
}

mysqli_close($conn);
?>
