<!DOCTYPE html>
<html>
<head>
  <title>My PHP page</title>
  
  <!-- Include CSS file -->
  <link rel="stylesheet" type="text/css" href="style333.css">
  
  <!-- Include JavaScript file -->
  <script src="script333.js"></script>
</head>
<body>
<?php
// Connect to your SQL database
$conn = mysqli_connect("localhost", "root", "", "art_gallery");


// Display the form and any error messages
?>
<h1>ArtWork Payment Page</h1>
<form method="post" action="add_to_bag.php">

    <label for="type">Artwork:</label>
    <select name="product_id">
        <?php
        // connect to database
    $conn = mysqli_connect("localhost", "root", "", "art_gallery");
        // Retrieve the concatenated values and loop through them
        $query = "SELECT CONCAT(artid, ' - ', title) AS id_and_name FROM artwork";
        $result = mysqli_query($conn, $query);
        while ($row = mysqli_fetch_assoc($result)) {
            // Split the concatenated value to retrieve the id and product name separately
            $id_and_name = $row['id_and_name'];
            $id = explode(' - ', $id_and_name)[0];
            $product_name = explode(' - ', $id_and_name)[1];

            // Output the option tag with the id as the value and the concatenated value as the display text
            echo "<option value=\"$id\">$id_and_name</option>";
        }
        ?>
    </select>
    <label><br>Enter the Id Showing in Artwork:</label>
  <input type="text" name="prd_id" required>
  <br>
  <label><br>Quantity:</label>
  <input type="number" name="qty" required>
  <br>
  <button type="submit" name="submit" value="Submit">Add to Bag</button>
</form>


<?php if (isset($error)) { echo "<p>$error</p>"; } ?>
</body>
</html>





















