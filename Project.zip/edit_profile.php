<?php
error_reporting(0);
session_start();

if(!isset($_SESSION["user"])){
  header("Location: login.php");
}



if(isset($_POST["name"]) && isset($_POST["gender"]) && isset($_POST["phone"]) && isset($_FILES['file']['name'])){

$name=$_POST["name"];
$phone=$_POST["phone"];
$gender=$_POST["gender"];



$fname = $_FILES['file']['name'];
$fsize = $_FILES['file']['size'];
$type = $_FILES['file']['type'];
$tmp_name = $_FILES['file']['tmp_name'];
$location = 'dp/';

$md5 = md5($fname.$fsize.$type);

$title = md5($md5);

$newname = $title.".jpg";

if(isset($fname)){
  if(!empty($fname)){
    move_uploaded_file($tmp_name, $location.$newname);
  }
}




$conn=mysqli_connect('localhost','root','','shopdb');

 if(!$conn) {
      die('Could not connect');
   }
   
   $sql="UPDATE users SET name='$name',gender='$gender', phone='$phone' WHERE username='".$_SESSION["user"]."'";



   $retval = mysqli_query( $conn, $sql );
   
   if(!$retval) {
      die('Could not update data');
   }
   
  
   
   mysqli_close($conn);

   header("Location: profile.php");
   die();
   }



?>
<!DOCTYPE html>
<html>
<head>
	<title>Edit Profile</title>
	<meta charset="UTF-8">
	<link rel="icon" href="image/fevicon.png">
	<link href="https://fonts.googleapis.com/css?family=Noto+Sans|Roboto:400,900" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/style.css">

	<style type="text/css">
	   body{
      margin-top: 130px;
     }
    .profile_pic{
      min-height: 200px;
      max-height: 200px;
      min-width: 200px;
      max-width: 200px;
      background-color: #7fcdc9;
      border-radius: 5px;
    }

    .contents{
      min-height: 450px;
      min-width: 100%;
      border: 1px solid rgba(0,0,0,50);
      border-radius: 3px;
      padding:40px 40px 40px 40px;
    }
    .inner_cont4{
      width: 80%;

    }
    body {
  background-image: url('/Images/artist2.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
   }
   .button-85 {
  padding: 0.6em 2em;
  border: none;
  outline: none;
  color: rgb(255, 255, 255);
  background: #111;
  cursor: pointer;
  position: relative;
  z-index: 0;
  border-radius: 10px;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
}

.button-85:before {
  content: "";
  background: linear-gradient(
    45deg,
    #ff0000,
    #ff7300,
    #fffb00,
    #48ff00,
    #00ffd5,
    #002bff,
    #7a00ff,
    #ff00c8,
    #ff0000
  );
  position: absolute;
  top: -2px;
  left: -2px;
  background-size: 400%;
  z-index: -1;
  filter: blur(5px);
  -webkit-filter: blur(5px);
  width: calc(100% + 4px);
  height: calc(100% + 4px);
  animation: glowing-button-85 20s linear infinite;
  transition: opacity 0.3s ease-in-out;
  border-radius: 10px;
}

@keyframes glowing-button-85 {
  0% {
    background-position: 0 0;
  }
  50% {
    background-position: 400% 0;
  }
  100% {
    background-position: 0 0;
  }
}

.button-85:after {
  z-index: -1;
  content: "";
  position: absolute;
  width: 100%;
  height: 100%;
  background: #222;
  left: 0;
  top: 0;
  border-radius: 10px;
}
    
	
	</style>
</head>
<body>




    <div class="inner_cont4">
      <div class="container">
        <div class="row">
         <div class="col-sm-4">
           <div class="profile_pic" ><br><br><form enctype="multipart/form-data" action="edit_profile.php" method="post"><input type="file" name="file" ></div><br>
          </div>


          <div class="col-sm-8">
            <div class="contents">
              <div style="font-size: 20pt; color: rgba(0,0,0,25); font-weight: 1000;">Primary Information</div><br>
              <hr>
              <table border="3" cellpadding="10" cellspacing="0" align="left" width="70%" height="250px" style="color: rgba(0,0,0,0.6);">
                <tr>
                  <td>Name : </td>
                  <td><input type="text" name="name"></td>
                </tr>
                <tr>
                  <td>Gender : </td>
                  <td><select name="gender"><option>Male</option><option>Female</option></select></td>
                </tr>
                <tr>
                  <td>Phone : </td>
                  <td><input type="number" name="phone"></td>
                </tr>
                <tr>
                  <td colspan="2"><input type="submit" name="" class="button-85" value="save"></form></td>
                </tr>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    



</body>
</html>