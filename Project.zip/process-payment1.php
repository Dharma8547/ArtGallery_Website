<!DOCTYPE html>
<html>
<head>
	<title>Gallery Payment Page</title>
	<link rel="stylesheet" type="text/css" href="style22.css">
</head>
<body>
	<h1>Gallery Payment Page</h1>
	<form method="post" action="process-payment1.php">

    <label for="type">Gallery:</label>
    <select id="type" name="type">
    <?php
    // connect to database
    $conn = mysqli_connect("localhost", "root", "", "art_gallery");

    // execute query
    $sql = "SELECT CONCAT(gname, ' - ', location) AS display_value FROM gallery";
    $result = mysqli_query($conn, $sql);

    // store results in an array
    $options = array();
    while ($row = mysqli_fetch_assoc($result)) {
     $options[] = $row['display_value'];
    }
    ?>
    <?php foreach ($options as $option): ?>
    <option value="<?php echo $option; ?>"><?php echo $option; ?></option>
    <?php endforeach; ?>
    </select>


    <label for="type">Payment Mode:</label>
    <select id="type" name="type">
    <?php
    $types = array('PayPal', 'CreditCard', 'COD(Cash on Delivery)');
    foreach ($types as $t) {
      echo '<option value="' . $t . '">' . ucfirst($t) . '</option>';
    }
     ?>
    </select>
		<br>
		<input type="submit" value="Submit Payment">
	</form>
</body>
</html>




<?php
// Connect to the database
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'art_gallery';

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
mysqli_close($conn);
?>
