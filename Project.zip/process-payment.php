<!DOCTYPE html>
<html>
<head>
  <title>My PHP page</title>
  
  <!-- Include CSS file -->
  <link rel="stylesheet" type="text/css" href="style333.css">
  
  <!-- Include JavaScript file -->
  <script src="script333.js"></script>
</head>
<body>
<?php
session_start();
$value = $_SESSION['orderid'];
echo "<span style='font-weight:bold;font-size:30px;color:limeblue'>Your order ID is: $value </span>";
// Connect to your SQL database
$conn = mysqli_connect("localhost", "root", "", "art_gallery");

// Validate the form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST["name"];
  $email = $_POST["email"];
  $payment_method = $_POST["payment_method"];
  
  
  // Insert the payment details into the database
  $sql = "INSERT INTO payments (orderid,name, email, payment_method) VALUES ('$value','$name', '$email', '$payment_method')";
  mysqli_query($conn, $sql);
  
  // Redirect the user to the payment gateway
  if ($payment_method == "paypal") {
    header("Location: https://www.paypal.com/");
  } else if ($payment_method == "credit_card") {
    header("Location: https://www.example.com/credit-card-payment/");
  }
}

// Display the form and any error messages
?>
<h1>ArtWork Payment Page</h1>
<form method="post" action="process-payment.php">

    
  <label><br>Name:</label>
  <input type="text" name="name" required>
  <br>
  
  <label><br>Email:</label>
  <input type="email" name="email" required>
  <br>

  
  <label><br>Payment Method:</label>
  <input type="radio" name="payment_method" value="paypal" checked> PayPal
  <br>
  <input type="radio" name="payment_method" value="credit_card" required> Credit Card
  <br>
  
  <button type="submit">Submit Payment</button>
</form>

<?php if (isset($error)) { echo "<p>$error</p>"; } ?>
</body>
</html>























