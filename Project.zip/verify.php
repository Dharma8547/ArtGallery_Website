<?php
session_start();

// Check if user submitted the login form
if(isset($_POST['username']) && isset($_POST['password'])){
	// Retrieve user's credentials
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	// Verify user's credentials (replace this with your own authentication logic)
	if($username == 'demo' && $password == 'demo'){
		// Authentication successful, store user's ID in a session variable
		$_SESSION['user_id'] = 1;
		
		// Redirect user to profile page
		header('Location: prf.php');
		exit;
	} else {
		// Authentication failed, redirect user back to authentication page
		header('Location: authenticate.php');
		exit;
	}
} else {
	// User did not submit the login form, redirect them back to the authentication page
	header('Location: authenticate.php');
	exit;
}
?>