<?php
// Start session
session_start();

// Retrieve login data from form
$username = $_POST["username"];
$password = $_POST["password"];

// Connect to database
$servername = "localhost";
$username_db = "root";
$password_db = "";
$dbname = "shopdb";
$conn = mysqli_connect($servername, $username_db, $password_db, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Prepare SQL statement
$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";

// Execute SQL statement
$result = mysqli_query($conn, $sql);

// Check if login is valid
if (mysqli_num_rows($result) == 1) {
  // Login is valid, store username in session
  $_SESSION["username"] = $username;

  // Redirect to profile page
  header("Location: profile1.php");
  exit();
} else {
  // Invalid login, show error message
  echo "Invalid login";
}

// Close database connection
mysqli_close($conn);
?>