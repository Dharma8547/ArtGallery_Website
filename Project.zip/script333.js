// Get the form and its inputs
const form = document.querySelector('form');
const nameInput = form.querySelector('input[name="name"]');
const emailInput = form.querySelector('input[name="email"]');
const quantityInput = form.querySelector('input[name="quantity"]');
const paymentMethodInputs = form.querySelectorAll('input[name="payment_method"]');

// Add form submission listener
form.addEventListener('submit', (event) => {
  // Prevent the form from submitting
  event.preventDefault();
  
  // Validate the form inputs
  let isValid = true;
  if (nameInput.value.trim() === '') {
    nameInput.classList.add('error');
    isValid = false;
  } else {
    nameInput.classList.remove('error');
  }
  if (emailInput.value.trim() === '' || !isValidEmail(emailInput.value.trim())) {
    emailInput.classList.add('error');
    isValid = false;
  } else {
    emailInput.classList.remove('error');
  }
  if (quantityInput.value.trim() === '' || isNaN(quantityInput.value.trim()) || quantityInput.value.trim() <= 0) {
    quantityInput.classList.add('error');
    isValid = false;
  } else {
    quantityInput.classList.remove('error');
  }
  let paymentMethodSelected = false;
  for (const input of paymentMethodInputs) {
    if (input.checked) {
      paymentMethodSelected = true;
      break;
    }
  }
  if (!paymentMethodSelected) {
    paymentMethodInputs[0].classList.add('error');
    isValid = false;
  } else {
    paymentMethodInputs[0].classList.remove('error');
  }
  
  // Submit the form if it's valid
  if (isValid) {
    form.submit();
  }
});

// Add input change listeners to remove error message when user types
nameInput.addEventListener('input', () => {
  nameInput.classList.remove('error');
});
emailInput.addEventListener('input', () => {
  emailInput.classList.remove('error');
});
quantityInput.addEventListener('input', () => {
  quantityInput.classList.remove('error');
});
for (const input of paymentMethodInputs) {
  input.addEventListener('change', () => {
    paymentMethodInputs[0].classList.remove('error');
  });
}

// Helper function to validate email addresses
function isValidEmail(email) {
  const regex = /^[^\s@]+@[
