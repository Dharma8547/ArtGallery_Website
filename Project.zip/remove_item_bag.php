<?php
error_reporting(0);
session_start();

if(!isset($_SESSION["user"])){
  header("Location: login.php");
}


if(isset($_GET["user"]) && isset($_GET["item"]) && isset($_GET["qty"])){

$user=$_GET["user"];
$item=$_GET["item"];
$qty=$_GET["qty"];

$conn=mysqli_connect('localhost','root','','art_gallery');

 if(!$conn) {
      die('Could not connect');
   }

   
   $sql = "DELETE FROM bag WHERE username='$user' AND prod_id='$item' AND qty='$qty'";



   $retval = mysqli_query( $conn, $sql );
   
   if(!$retval) {
      die('Could not delete data');
   }
   
  
   
   mysqli_close($conn);

   header("Location: bag.php");
   die();
   }
   header("Location: bag.php");

?>