<?php
error_reporting(0);
session_start();


$username=$_SESSION["user"];

$conn=mysqli_connect('localhost','root','','shopdb');

 if(!$conn ) {
      die('Could not connect');
   }
   
   $sql = 'SELECT * FROM users WHERE username="'.$username.'"';


      
   $retval = mysqli_query( $conn, $sql );
   
   if(! $retval) {
      die('Could not select data');
   }
   
  
 $row = mysqli_fetch_array($retval, MYSQLI_BOTH);

      $name=$row[0];
      $uname=$row[1];
      $pass=$row[2];
      $pic=$row[3];
      $gender=$row[4];
      $phone=$row[5];

   mysqli_close($conn);


?>
<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
	<meta charset="UTF-8">
	<link rel="icon" href="image/fevicon.png">
	<link href="https://fonts.googleapis.com/css?family=Noto+Sans|Roboto:400,900" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/style.css">

	<style type="text/css">
	   body{
      margin-top: 130px;
     }
    .profile_pic{
      min-height: 200px;
      max-height: 200px;
      min-width: 200px;
      max-width: 200px;
      background-color: #7fcdc9;
      border-radius: 5px;
    }

    .contents{
      min-height: 450px;
      min-width: 100%;
      border: 1px solid rgba(0,0,0,0.2);
      border-radius: 3px;
      padding:40px 40px 40px 40px;
    }
    .inner_cont4{
      width: 80%;

    }
    
	
	</style>
</head>
<body>


    <div class="inner_cont4">
      <div class="container">
        <div class="row">
        


          <div class="col-sm-8">
            <div class="contents">
              <div style="font-size: 20pt; color: rgba(0,0,0,0.5); font-weight: lighter;">Primary Information</div><br>
              <hr>
              <table border="0" cellpadding="0" cellspacing="0" align="left" width="70%" height="250px" style="color: rgba(0,0,0,0.6);">
                <tr>
                  <td>Name : </td>
                  <td><b><?php echo $name; ?></b></td>
                </tr>
                <tr>
                  <td>Username : </td>
                  <td><?php echo $uname; ?></td>
                </tr>
                <tr>
                  <td>Gender : </td>
                  <td><?php echo $gender; ?></td>
                </tr>
                <tr>
                  <td>Phone : </td>
                  <td><?php echo $phone; ?></td>
                </tr>
                <tr>
                  <td colspan="2"><a href="edit_profile1.php"><button class="btn btn-outline-info">Edit Profile</button></a> &nbsp <a href="orders.php"><button class="btn btn-outline-info">Track Order</button></a></td>
                </tr>
              </table>
              

            </div><br>

              
              <br><br>

              <td><a href="FrontEnd.html"><button class="btn btn-outline-info">Art Gallery</button></a></td>
          </div>
                 
        </div>
      </div>
      
    </div>
         

    
    



</body>
</html>