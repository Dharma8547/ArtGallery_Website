<?php
session_start();

// Check if user is logged in
if(isset($_SESSION['user_id'])){
	// User is logged in, retrieve user's ID from session variable
	$user_id = $_SESSION['user_id'];
	
	// Display user's profile information
	echo "<h1>Welcome User $user_id</h1>";
} else {
	// User is not logged in, redirect them back to the authentication page
	header('Location: authenticate.php');
	exit;
}
?>