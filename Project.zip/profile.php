<?php
error_reporting(0);
session_start();
if(!isset($_SESSION["user"])){
  header('Location: login.php');
}



$username=$_SESSION["user"];

$conn=mysqli_connect('localhost','root','','shopdb');

 if(!$conn ) {
      die('Could not connect');
   }
   
   $sql = 'SELECT * FROM users WHERE username="'.$username.'"';


      
   $retval = mysqli_query( $conn, $sql );
   
   if(! $retval) {
      die('Could not select data');
   }
   
  
 $row = mysqli_fetch_array($retval, MYSQLI_BOTH);

      $name=$row[0];
      $uname=$row[1];
      $pass=$row[2];
      $pic=$row[3];
      $gender=$row[4];
      $phone=$row[5];

   mysqli_close($conn);


?>
<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
	<meta charset="UTF-8">
	<link rel="icon" href="image/fevicon.png">
	<link href="https://fonts.googleapis.com/css?family=Noto+Sans|Roboto:400,900" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/style.css">

	<style type="text/css">
	   body{
      margin-top: 130px;
     }
    .profile_pic{
      min-height: 200px;
      max-height: 200px;
      min-width: 200px;
      max-width: 200px;
      background-color: #7fcdc9;
      border-radius: 5px;
    }

    .contents{
      min-height: 450px;
      min-width: 100%;
      border: 1px solid rgba(0,0,0,25);
      border-radius: 3px;
      padding:40px 40px 40px 40px;
    }
    .inner_cont4{
      width: 80%;

    }

body {
  background-image: url('/Images/artist1.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}
.button-85 {
  padding: 0.6em 2em;
  border: none;
  outline: none;
  color: rgb(255, 255, 255);
  background: #111;
  cursor: pointer;
  position: relative;
  z-index: 0;
  border-radius: 10px;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
}

.button-85:before {
  content: "";
  background: linear-gradient(
    45deg,
    #ff0000,
    #ff7300,
    #fffb00,
    #48ff00,
    #00ffd5,
    #002bff,
    #7a00ff,
    #ff00c8,
    #ff0000
  );
  position: absolute;
  top: -2px;
  left: -2px;
  background-size: 400%;
  z-index: -1;
  filter: blur(5px);
  -webkit-filter: blur(5px);
  width: calc(100% + 4px);
  height: calc(100% + 4px);
  animation: glowing-button-85 20s linear infinite;
  transition: opacity 0.3s ease-in-out;
  border-radius: 10px;
}

@keyframes glowing-button-85 {
  0% {
    background-position: 0 0;
  }
  50% {
    background-position: 400% 0;
  }
  100% {
    background-position: 0 0;
  }
}

.button-85:after {
  z-index: -1;
  content: "";
  position: absolute;
  width: 100%;
  height: 100%;
  background: #222;
  left: 0;
  top: 0;
  border-radius: 10px;
}
	
	</style>
</head>
<body>



    <div class="inner_cont4">
      <div class="container">
        <div class="row">
          <div class="col-sm-4" align="right">
            <div class="profile_pic" >
            <img src="/Images/artist.jpg" width="200" height="200">
            <br>
            <br>
            <br>
            <br>
            <td><a href="FrontEnd.html"><button  class="button-85">Art Gallery</button></a></td>
          
          </div>
            <span style="padding-left: 60px; font-size: 13pt; text-transform: uppercase; font-family: 'Roboto', sans-serif; color: rgba(0,0,0,0.7); font-weight: 1000;"><b><?php echo $_SESSION["name"];?></b></span>
          </div>


          <div class="col-sm-8" border-width: thick>
            <div class="contents">
              <div style="font-size: 20pt; color: rgba(0,0,0,0.5); font-weight: 1000;">Primary Information</div><br>
              <hr>
              <table border="6" cellpadding="10" cellspacing="0" align="left" width="70%" height="250px" style="color: rgba(0,0,0,60);">
                <tr>
                  <td>Name : </td>
                  <td><b><?php echo $name; ?></b></td>
                </tr>
                <tr>
                  <td>Username : </td>
                  <td><?php echo $uname; ?></td>
                </tr>
                <tr>
                  <td>Gender : </td>
                  <td><?php echo $gender; ?></td>
                </tr>
                <tr>
                  <td>Phone : </td>
                  <td><?php echo $phone; ?></td>
                </tr>
                <tr>
                  <td colspan="2"><a href="edit_profile.php"><button  class="button-85">Edit Profile</button></a> &nbsp <a href="orders.php"><button  class="button-85">Track Order</button></a></td>
                </tr>
              </table>
              

            </div><br>

              <?php
                try{
                  if($_SESSION["admin"]==$_SESSION["user"]){

                    echo '<div class="contents" style="min-height:300px;">
              <div style="font-size: 20pt; color: rgba(0,0,0,0.5); font-weight: 1000;">Admin Panel</div><br>
              <hr>
              <table border="6" cellpadding="10" cellspacing="0" align="left" width="70%" height="130px" style="color: rgba(0,0,0,60);">
              
                <tr>
                  <td>Order Status</td>
                  <td><a href="_status.php"   class="button-85">Status</a></td>
                </tr>
                <tr>
                  <td>User Login Info</td>
                  <td><a href="_log.php"  class="button-85">Info</a></td>
                </tr>
              </table>
            </div>';
                }
              }catch(Exception $e){

              }
              ?>
              
              <br><br>
             
              <a href="login.php"><button  class="button-85">Sign Out</button></a>
          </div>
                   
        </div>
      </div>
    </div>

    



</body>
</html>