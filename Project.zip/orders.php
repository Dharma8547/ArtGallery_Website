<?php
error_reporting(0);
session_start();
if(!isset($_SESSION["user"])){
  header("Location: login.php");
}


$curr_user = $_SESSION["user"];
$total=0;

$conn=mysqli_connect('localhost','root','','art_gallery');

 if(!$conn ) {
      die('Could not connect');
   }
   
   $sql = "SELECT prod_id, qty, order_id FROM orders WHERE username='$curr_user'";


      
   $retval = mysqli_query( $conn, $sql );
   
   if(! $retval) {
      die('Could not select data');
   }
   
  $i=0;
   while($row = mysqli_fetch_assoc($retval)){

    $arr[$i]=$row;
    $i++;
}


   mysqli_close($conn);




?>

<!DOCTYPE html>
<html>
<head>
  <title>Orders</title>
  <meta charset="UTF-8">
  <link rel="icon" href="image/fevicon.png">
  <link href="https://fonts.googleapis.com/css?family=Noto+Sans|Roboto:400,900" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
  <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="js/popper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css">

  <style type="text/css">
    body{
      margin-top: 100px;
    }
    

    .prod_box{
      min-height: 170px;
      max-height: 170px;
      min-width: 650px;
      max-width: 650px;
      border: 5px solid pink;
    }

    .price_box{
      min-width: 300px;
      max-width: 300px;
      min-height: 320px;
      border: 5px solid pink;
    }
    
    /* body {
  background-image: url('/Images/artist4.avif');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
} */
  </style>
</head>
<body>


    <div class="inner_cont2">
    <div class="container">
      <div style="font-family: 'Roboto', sans-serif; color: brown; font-weight: 700; font-size: 15pt">My Orders</div><br><br>
      <div class="row">
        <div class="col-12">

          <?php

          foreach ($arr as $prodd) {
            $total = $total+$prodd["price"];
            echo '<div class="prod_box">
            <div style="font-weight: 700; color: blue; padding-bottom: 10px; padding-left: 10px; font-size: 10pt; padding-top: 10px"><b>Product ID: </b>'.$prodd["prod_id"].'</div>
            <div style="font-weight: 700; color: blue; padding-bottom: 10px; padding-left: 10px; font-size: 10pt; padding-top: 10px"><b>Order ID: </b>'.$prodd["order_id"].'</div>
            &nbsp &nbsp <b>Quantity:</b> '.$prodd["qty"].'</div><hr>
            <div style="font-size: 10pt; font-weight: 700">';
            // if($prodd["status"]==0){ 
            //   echo 'processing';
            // } elseif ($prodd["status"]==1) {
            //   echo 'shipped';
            // }else{
            //   echo "delivered";
            // }
            echo '</div><br>';
          }

          ?>

        </div>
      </div>

    </div>
    </div>


    <br><br><br>

     
</body>
</html>